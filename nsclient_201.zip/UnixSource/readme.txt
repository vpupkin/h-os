Compilation HOWTO
-----------------

22.05.2002 Timothy Shouldice
---------------------
This version of check_nt is designed to compile with the Nagios Plugins 1.3.0
This file goes in the plugins subdirectory.
Make a backup copy of the original and then overwrite it with this version.
Inside the plugins directory, simply type 'make' and the executable will be recompiled.

															
